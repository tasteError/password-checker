﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pwd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!=String.Empty && textBox2.Text!=string.Empty)
            {

            
            if (textBox1.Text == textBox2.Text)
            {
                lblcmp.Text = "Matched";
                lblcmp.ForeColor = Color.Green;
            }
            else
            {
                lblcmp.Text = "Mis-Matched";
                lblcmp.ForeColor = Color.Red;
            }
            }
            else
            {
                MessageBox.Show("Enter all fields");
            }
        }
    }
}
